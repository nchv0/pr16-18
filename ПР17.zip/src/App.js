import React from 'react';
import './App.css';
import UserRegistrationForm from './components/UserRegistrationForm';
import UserRegistrationFormWithValidation from './components/UserRegistrationFormWithValidation';
import ContactFormUncontrolled from './components/ContactFormUncontrolled';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Практическая работа №17: React формы</h1>
        <p>Управляемые и неуправляемые компоненты, валидация</p>
      </header>
      <main>
        <UserRegistrationForm />
        <UserRegistrationFormWithValidation />
        <ContactFormUncontrolled />
      </main>
    </div>
  );
}

export default App;
