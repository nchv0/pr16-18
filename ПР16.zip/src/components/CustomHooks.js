import React, { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useFetch } from '../hooks/useFetch';
import { useToggle } from '../hooks/useToggle';

const CustomHooks = () => {
  // useLocalStorage пример
  const [name, setName] = useLocalStorage('username', '');
  const [theme, setTheme] = useLocalStorage('theme', 'light');

  // useFetch пример
  const [userId, setUserId] = useState(1);
  const { data: user, loading, error } = useFetch(
    `https://jsonplaceholder.typicode.com/users/${userId}`
  );

  // useToggle пример
  const [isOn, toggleActions] = useToggle(false);

  return (
    <div style={{ 
      padding: '20px', 
      border: '1px solid #ccc', 
      margin: '10px',
      backgroundColor: theme === 'dark' ? '#333' : '#fff',
      color: theme === 'dark' ? '#fff' : '#000'
    }}>
      <h2>Кастомные хуки</h2>

      {/* useLocalStorage секция */}
      <div>
        <h3>useLocalStorage демонстрация</h3>
        <input
          type="text"
          placeholder="Введите имя (сохраняется в localStorage)"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <p>Сохраненное имя: {name}</p>
        
        <div>
          <button onClick={() => setTheme('light')}>Светлая тема</button>
          <button onClick={() => setTheme('dark')}>Темная тема</button>
        </div>
      </div>

      {/* useFetch секция */}
      <div style={{ marginTop: '20px' }}>
        <h3>useFetch демонстрация</h3>
        <div>
          <button onClick={() => setUserId(1)}>Пользователь 1</button>
          <button onClick={() => setUserId(2)}>Пользователь 2</button>
          <button onClick={() => setUserId(3)}>Пользователь 3</button>
        </div>
        
        {loading && <p>Загрузка...</p>}
        {error && <p style={{ color: 'red' }}>Ошибка: {error}</p>}
        {user && (
          <div>
            <h4>{user.name}</h4>
            <p>Email: {user.email}</p>
            <p>Телефон: {user.phone}</p>
          </div>
        )}
      </div>

      {/* useToggle секция */}
      <div style={{ marginTop: '20px' }}>
        <h3>useToggle демонстрация</h3>
        <p>Состояние: {isOn ? 'ВКЛ' : 'ВЫКЛ'}</p>
        <button onClick={toggleActions.toggle}>Переключить</button>
        <button onClick={toggleActions.setTrue}>Включить</button>
        <button onClick={toggleActions.setFalse}>Выключить</button>
      </div>
    </div>
  );
};

export default CustomHooks;