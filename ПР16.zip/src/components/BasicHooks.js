import React, { useState, useEffect } from 'react';

const BasicHooks = () => {
  // useState пример
  const [count, setCount] = useState(0);
  const [name, setName] = useState('');
  const [isVisible, setIsVisible] = useState(true);

  // useEffect примеры
  useEffect(() => {
    console.log('Компонент смонтирован');
    
    return () => {
      console.log('Компонент будет размонтирован');
    };
  }, []);

  useEffect(() => {
    document.title = `Счетчик: ${count}`;
  }, [count]);

  useEffect(() => {
    console.log(`Имя изменено на: ${name}`);
  }, [name]);

  const increment = () => setCount(prev => prev + 1);
  const decrement = () => setCount(prev => prev - 1);
  const reset = () => setCount(0);
  const toggleVisibility = () => setIsVisible(prev => !prev);

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', margin: '10px' }}>
      <h2>Базовые хуки</h2>
      
      <div>
        <h3>useState демонстрация</h3>
        <p>Счетчик: {count}</p>
        <button onClick={increment}>+1</button>
        <button onClick={decrement}>-1</button>
        <button onClick={reset}>Сброс</button>
        
        <div style={{ marginTop: '10px' }}>
          <input
            type="text"
            placeholder="Введите имя"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <p>Привет, {name || 'незнакомец'}!</p>
        </div>
        
        <div style={{ marginTop: '10px' }}>
          <button onClick={toggleVisibility}>
            {isVisible ? 'Скрыть' : 'Показать'}
          </button>
          {isVisible && <p>Этот текст можно скрыть/показать</p>}
        </div>
      </div>
      
      <div style={{ marginTop: '20px' }}>
        <h3>useEffect демонстрация</h3>
        <p>Проверьте консоль и заголовок вкладки браузера</p>
      </div>
    </div>
  );
};

export default BasicHooks;