import React from 'react';
import './App.css';
import HooksTests from './components/HooksTests';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Практическая работа №16: React хуки</h1>
        <p>Изучение встроенных и кастомных хуков React</p>
      </header>
      <main>
        <HooksTests />
      </main>
    </div>
  );
}

export default App;
