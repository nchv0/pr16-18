import React from 'react';
import BasicHooks from './BasicHooks';
import AdvancedHooks from './AdvancedHooks';
import CustomHooks from './CustomHooks';

const HooksTests = () => {
  return (
    <div>
      <h1>Тестирование React хуков</h1>
      <BasicHooks />
      <AdvancedHooks />
      <CustomHooks />
    </div>
  );
};

export default HooksTests;