import React, { useReducer, useContext, createContext, useCallback, useMemo, useRef, memo } from 'react';

// Контекст для useContext
const ThemeContext = createContext();

// useReducer пример
const initialState = { count: 0 };

function reducer(state, action) {
  switch (action.type) {
    case 'increment':
      return { count: state.count + 1 };
    case 'decrement':
      return { count: state.count - 1 };
    case 'reset':
      return initialState;
    default:
      throw new Error();
  }
}

// Упрощенный мемоизированный компонент
const SimpleDisplay = memo(({ value }) => {
  console.log('SimpleDisplay перерендерен');
  return <div>Значение: {value}</div>;
});

const AdvancedHooks = () => {
  // useReducer
  const [state, dispatch] = useReducer(reducer, initialState);

  // useContext с проверкой
  const theme = useContext(ThemeContext) || { color: 'black', backgroundColor: 'white' };

  // useRef
  const inputRef = useRef(null);
  const renderCount = useRef(0);

  renderCount.current++;

  // useCallback
  const [number, setNumber] = React.useState(1);
  
  const simpleCalculation = useCallback((num) => {
    console.log('Выполняется расчет...');
    return num * 2;
  }, []);

  // useMemo
  const memoizedValue = useMemo(() => {
    console.log('Вычисление memoized значения...');
    return number * 2;
  }, [number]);

  const focusInput = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  return (
    <ThemeContext.Provider value={{ color: 'blue', backgroundColor: 'lightgray' }}>
      <div style={{ 
        padding: '20px', 
        border: '1px solid #ccc', 
        margin: '10px',
        backgroundColor: theme.backgroundColor 
      }}>
        <h2 style={{ color: theme.color }}>Продвинутые хуки</h2>
        
        {/* useReducer секция */}
        <div>
          <h3>useReducer демонстрация</h3>
          <p>Счетчик: {state.count}</p>
          <button onClick={() => dispatch({ type: 'increment' })}>+</button>
          <button onClick={() => dispatch({ type: 'decrement' })}>-</button>
          <button onClick={() => dispatch({ type: 'reset' })}>Сброс</button>
        </div>

        {/* useRef секция */}
        <div style={{ marginTop: '20px' }}>
          <h3>useRef демонстрация</h3>
          <p>Компонент перерендерен: {renderCount.current} раз</p>
          <input ref={inputRef} type="text" placeholder="Фокус по кнопке" />
          <button onClick={focusInput}>Фокус на input</button>
        </div>

        {/* useCallback и useMemo секция */}
        <div style={{ marginTop: '20px' }}>
          <h3>useCallback и useMemo демонстрация</h3>
          <input
            type="number"
            value={number}
            onChange={(e) => setNumber(parseInt(e.target.value) || 0)}
          />
          <p>Memoized значение: {memoizedValue}</p>
          <SimpleDisplay value={number} />
        </div>
      </div>
    </ThemeContext.Provider>
  );
};

export default AdvancedHooks;