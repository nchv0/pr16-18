import React, { useRef } from 'react';
import './FormStyles.css';

const ContactFormUncontrolled = () => {
  const formRef = useRef(null);
  const nameRef = useRef(null);
  const emailRef = useRef(null);
  const subjectRef = useRef(null);
  const messageRef = useRef(null);
  const priorityRef = useRef(null);
  const subscribeRef = useRef(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = {
      name: nameRef.current.value,
      email: emailRef.current.value,
      subject: subjectRef.current.value,
      message: messageRef.current.value,
      priority: priorityRef.current.value,
      subscribe: subscribeRef.current.checked
    };

    console.log('Данные формы (неуправляемая):', formData);
    alert('Форма обратной связи отправлена! Проверьте консоль.');

    // Очистка формы
    formRef.current.reset();
  };

  const handleClear = () => {
    formRef.current.reset();
  };

  return (
    <div className="form-container">
      <h2>Форма обратной связи (неуправляемая)</h2>
      <form ref={formRef} onSubmit={handleSubmit} className="contact-form">
        {/* Имя */}
        <div className="form-group">
          <label htmlFor="uncontrolled-name">Имя:</label>
          <input
            type="text"
            id="uncontrolled-name"
            ref={nameRef}
            defaultValue=""
          />
        </div>

        {/* Email */}
        <div className="form-group">
          <label htmlFor="uncontrolled-email">Email:</label>
          <input
            type="email"
            id="uncontrolled-email"
            ref={emailRef}
            defaultValue=""
          />
        </div>

        {/* Тема */}
        <div className="form-group">
          <label htmlFor="uncontrolled-subject">Тема:</label>
          <input
            type="text"
            id="uncontrolled-subject"
            ref={subjectRef}
            defaultValue=""
          />
        </div>

        {/* Приоритет */}
        <div className="form-group">
          <label htmlFor="uncontrolled-priority">Приоритет:</label>
          <select
            id="uncontrolled-priority"
            ref={priorityRef}
            defaultValue="medium"
          >
            <option value="low">Низкий</option>
            <option value="medium">Средний</option>
            <option value="high">Высокий</option>
          </select>
        </div>

        {/* Сообщение */}
        <div className="form-group">
          <label htmlFor="uncontrolled-message">Сообщение:</label>
          <textarea
            id="uncontrolled-message"
            ref={messageRef}
            rows="5"
            defaultValue=""
          />
        </div>

        {/* Подписка */}
        <div className="form-group">
          <label className="checkbox-label">
            <input
              type="checkbox"
              ref={subscribeRef}
              defaultChecked={false}
            />
            Подписаться на уведомления
          </label>
        </div>

        <div className="button-group">
          <button type="submit" className="submit-btn">
            Отправить
          </button>
          <button type="button" onClick={handleClear} className="clear-btn">
            Очистить
          </button>
        </div>
      </form>

      <div className="form-info">
        <h3>Особенности неуправляемой формы:</h3>
        <ul>
          <li>Использует useRef для доступа к DOM элементам</li>
          <li>Значения получаются только при отправке формы</li>
          <li>Меньше ререндеров компонента</li>
          <li>Проще интеграция с нативными HTML формами</li>
        </ul>
      </div>
    </div>
  );
};

export default ContactFormUncontrolled;