import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import './styles/RouterStyles.css';

// Импорт компонентов маршрутизации
import Navigation from './components/Navigation';
import Home from './pages/Home';
import About from './pages/About';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Contact from './pages/Contact';
import ContactSuccess from './pages/ContactSuccess';
import NotFound from './pages/NotFound';

// Импорт компонентов из предыдущих работ
import HooksTests from './components/HooksTests';
import UserRegistrationForm from './components/UserRegistrationForm';
import UserRegistrationFormWithValidation from './components/UserRegistrationFormWithValidation';
import ContactFormUncontrolled from './components/ContactFormUncontrolled';

function App() {
  return (
    <Router>
      <div className="App">
        <Navigation />
        
        <main className="main-content">
          <Routes>
            {/* Основные маршруты */}
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/products" element={<Products />} />
            <Route path="/products/:id" element={<ProductDetail />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/contact/success" element={<ContactSuccess />} />
            
            {/* Маршруты для предыдущих практических работ */}
            <Route path="/pr16-hooks" element={<HooksTests />} />
            <Route path="/pr17-forms" element={
              <div className="page-container">
                <h1>Практическая работа №17: React формы</h1>
                <UserRegistrationForm />
                <UserRegistrationFormWithValidation />
                <ContactFormUncontrolled />
              </div>
            } />
            
            {/* Маршрут для несуществующих страниц */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        
        <footer className="app-footer">
          <p>React Router Demo &copy; 2025</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;