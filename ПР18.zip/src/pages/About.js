import React from 'react';
import { Link } from 'react-router-dom';

const About = () => {
  return (
    <div className="page-container">
      <h1>О нашей компании</h1>
      
      <div className="about-content">
        <section className="about-section">
          <h2>Наша история</h2>
          <p>
            Мы - современная IT компания, специализирующаяся на разработке 
            веб-приложений с использованием передовых технологий, включая React.
          </p>
        </section>

        <section className="about-section">
          <h2>Наша миссия</h2>
          <p>
            Создавать качественные и удобные веб-приложения, которые решают 
            реальные проблемы пользователей и улучшают их повседневную жизнь.
          </p>
        </section>

        <section className="about-section">
          <h2>Технологии</h2>
          <div className="tech-stack">
            <span className="tech-badge">React</span>
            <span className="tech-badge">React Router</span>
            <span className="tech-badge">JavaScript ES6+</span>
            <span className="tech-badge">HTML5 & CSS3</span>
            <span className="tech-badge">Node.js</span>
          </div>
        </section>
      </div>

      <div className="navigation-links">
        <Link to="/" className="btn btn-outline">← На главную</Link>
      </div>
    </div>
  );
};

export default About;