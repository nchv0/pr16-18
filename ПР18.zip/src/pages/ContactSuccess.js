import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const ContactSuccess = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  const { formData, timestamp } = location.state || {};

  const goHome = () => {
    navigate('/');
  };

  const goBackToContact = () => {
    navigate('/contact');
  };

  if (!formData) {
    return (
      <div className="page-container">
        <div className="success-message error">
          <h2>Ошибка!</h2>
          <p>Данные формы не найдены.</p>
          <Link to="/contact" className="btn btn-primary">
            Вернуться к форме
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="success-message">
        <div className="success-icon">✓</div>
        <h1>Сообщение отправлено!</h1>
        <p>Благодарим вас за обращение. Мы свяжемся с вами в ближайшее время.</p>
        
        <div className="submitted-data">
          <h3>Отправленные данные:</h3>
          <div className="data-grid">
            <div><strong>Имя:</strong> {formData.name}</div>
            <div><strong>Email:</strong> {formData.email}</div>
            <div><strong>Тема:</strong> {formData.subject}</div>
            <div><strong>Сообщение:</strong> {formData.message}</div>
            <div><strong>Время отправки:</strong> {timestamp}</div>
          </div>
        </div>

        <div className="action-buttons">
          <button onClick={goHome} className="btn btn-primary">
            На главную
          </button>
          <button onClick={goBackToContact} className="btn btn-outline">
            Отправить ещё одно сообщение
          </button>
          <Link to="/products" className="btn btn-secondary">
            Посмотреть товары
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ContactSuccess;