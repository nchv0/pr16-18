import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  // Имитация данных о товарах
  const products = {
    1: { name: 'Ноутбук', price: 50000, category: 'electronics', description: 'Мощный ноутбук для работы и игр' },
    2: { name: 'Смартфон', price: 30000, category: 'electronics', description: 'Современный смартфон с отличной камерой' },
    3: { name: 'Книга', price: 500, category: 'books', description: 'Интересная книга для чтения' },
    4: { name: 'Наушники', price: 5000, category: 'electronics', description: 'Качественные беспроводные наушники' },
    5: { name: 'Футболка', price: 1500, category: 'clothing', description: 'Удобная хлопковая футболка' },
    6: { name: 'Кофе', price: 300, category: 'food', description: 'Свежеобжаренный кофе' }
  };

  const product = products[id];

  if (!product) {
    return (
      <div className="page-container">
        <h2>Товар не найден</h2>
        <p>Товар с ID {id} не существует.</p>
        <Link to="/products" className="btn btn-primary">
          Вернуться к товарам
        </Link>
      </div>
    );
  }

  const goToProducts = () => {
    navigate('/products');
  };

  const goBack = () => {
    navigate(-1);
  };

  return (
    <div className="page-container">
      <div className="product-detail">
        <h1>{product.name}</h1>
        
        <div className="product-info">
          <div className="product-meta">
            <p><strong>Цена:</strong> {product.price} ₽</p>
            <p><strong>Категория:</strong> {product.category}</p>
            <p><strong>ID товара:</strong> {id}</p>
          </div>
          
          <div className="product-description">
            <h3>Описание</h3>
            <p>{product.description}</p>
          </div>
        </div>

        <div className="action-buttons">
          <button onClick={goBack} className="btn btn-outline">
            ← Назад
          </button>
          <button onClick={goToProducts} className="btn btn-primary">
            Все товары
          </button>
          <Link to="/contact" className="btn btn-success">
            Купить сейчас
          </Link>
        </div>

        {/* Демонстрация useParams */}
        <div className="debug-info">
          <h4>Информация о маршруте:</h4>
          <p>Параметр ID из URL: <code>{id}</code></p>
          <p>Текущий путь: <code>{window.location.pathname}</code></p>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;