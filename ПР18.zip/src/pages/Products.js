import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Products = () => {
  const [products] = useState([
    { id: 1, name: 'Ноутбук', price: 50000, category: 'electronics' },
    { id: 2, name: 'Смартфон', price: 30000, category: 'electronics' },
    { id: 3, name: 'Книга', price: 500, category: 'books' },
    { id: 4, name: 'Наушники', price: 5000, category: 'electronics' },
    { id: 5, name: 'Футболка', price: 1500, category: 'clothing' },
    { id: 6, name: 'Кофе', price: 300, category: 'food' }
  ]);

  const [filter, setFilter] = useState('all');

  const filteredProducts = filter === 'all' 
    ? products 
    : products.filter(product => product.category === filter);

  return (
    <div className="page-container">
      <h1>Наши товары</h1>
      
      {/* Фильтр по категориям */}
      <div className="filter-section">
        <h3>Фильтр по категориям:</h3>
        <div className="filter-buttons">
          <button 
            className={filter === 'all' ? 'btn btn-active' : 'btn btn-outline'}
            onClick={() => setFilter('all')}
          >
            Все
          </button>
          <button 
            className={filter === 'electronics' ? 'btn btn-active' : 'btn btn-outline'}
            onClick={() => setFilter('electronics')}
          >
            Электроника
          </button>
          <button 
            className={filter === 'books' ? 'btn btn-active' : 'btn btn-outline'}
            onClick={() => setFilter('books')}
          >
            Книги
          </button>
          <button 
            className={filter === 'clothing' ? 'btn btn-active' : 'btn btn-outline'}
            onClick={() => setFilter('clothing')}
          >
            Одежда
          </button>
        </div>
      </div>

      {/* Список товаров */}
      <div className="products-grid">
        {filteredProducts.map(product => (
          <div key={product.id} className="product-card">
            <h3>{product.name}</h3>
            <p className="product-price">{product.price} ₽</p>
            <p className="product-category">Категория: {product.category}</p>
            <Link 
              to={`/products/${product.id}`} 
              className="btn btn-primary"
            >
              Подробнее
            </Link>
          </div>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <p className="no-products">Товары не найдены</p>
      )}

      <div className="navigation-links">
        <Link to="/" className="btn btn-outline">← На главную</Link>
      </div>
    </div>
  );
};

export default Products;