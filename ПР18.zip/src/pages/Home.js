import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="page-container">
      <h1>Добро пожаловать на главную страницу!</h1>
      <p>Это демонстрационное приложение для изучения React Router.</p>
      
      <div className="feature-list">
        <h2>Возможности приложения:</h2>
        <ul>
          <li>Навигация между страницами</li>
          <li>Динамические маршруты с параметрами</li>
          <li>Программная навигация</li>
          <li>Обработка несуществующих страниц</li>
        </ul>
      </div>

      <div className="quick-links">
        <h3>Быстрые ссылки:</h3>
        <div className="link-group">
          <Link to="/about" className="btn btn-primary">О нас</Link>
          <Link to="/products" className="btn btn-secondary">Товары</Link>
          <Link to="/contact" className="btn btn-success">Контакты</Link>
        </div>
      </div>
    </div>
  );
};

export default Home;