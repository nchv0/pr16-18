import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Contact = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // В реальном приложении здесь была бы отправка данных на сервер
    console.log('Данные формы:', formData);
    
    // Программная навигация с передачей состояния
    navigate('/contact/success', { 
      state: { 
        formData: formData,
        timestamp: new Date().toLocaleString()
      }
    });
  };

  const handleCancel = () => {
    // Программная навигация назад
    navigate(-1);
  };

  return (
    <div className="page-container">
      <h1>Свяжитесь с нами</h1>
      
      <div className="contact-form-container">
        <form onSubmit={handleSubmit} className="contact-form">
          <div className="form-group">
            <label htmlFor="name">Имя:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="subject">Тема:</label>
            <input
              type="text"
              id="subject"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="message">Сообщение:</label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows="5"
              required
            />
          </div>

          <div className="form-actions">
            <button type="button" onClick={handleCancel} className="btn btn-outline">
              Отмена
            </button>
            <button type="submit" className="btn btn-success">
              Отправить сообщение
            </button>
          </div>
        </form>

        <div className="contact-info">
          <h3>Контактная информация</h3>
          <p><strong>Телефон:</strong> +7 (999) 123-45-67</p>
          <p><strong>Email:</strong> info@example.com</p>
          <p><strong>Адрес:</strong> г. Москва, ул. Примерная, д. 123</p>
        </div>
      </div>
    </div>
  );
};

export default Contact;